﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Lab4.Entities;
using Lab4.Repositories;

namespace Lab4.Forms
{
    public partial class FormSale : Form
    {
        private readonly ISaleRepository _saleRepository;
        private readonly IEquipmentRepository _equipmentRepository;
        private readonly ISellerRepository _sellerRepository;
        private readonly IClientRepository _clientRepository;

        // Временный список позиций продажи
        private List<SaleItem> _currentItems = new List<SaleItem>();

        public FormSale(
            ISaleRepository saleRepository,
            IEquipmentRepository equipmentRepository,
            ISellerRepository sellerRepository,
            IClientRepository clientRepository)
        {
            InitializeComponent();

            _saleRepository = saleRepository;
            _equipmentRepository = equipmentRepository;
            _sellerRepository = sellerRepository;
            _clientRepository = clientRepository;

            LoadComboBoxes();
            RefreshItemsGrid();

            // === ОБЯЗАТЕЛЬНО ПРИВЯЗЫВАЕМ СОБЫТИЯ КНОПОК ===
            btnAddItem.Click += btnAddItem_Click;
            btnSave.Click += btnSave_Click;
        }

        private void LoadComboBoxes()
        {
            // Продавцы
            cmbSeller.DisplayMember = "FirstName";  
            cmbSeller.ValueMember = "Id";
            cmbSeller.DataSource = _sellerRepository.ReadEntities().ToList();

            // Клиенты
            cmbClient.DisplayMember = "FirstName";
            cmbClient.ValueMember = "Id";
            cmbClient.DataSource = _clientRepository.ReadEntities().ToList();

            // Товары для добавления — с количеством на складе
            var equipmentList = _equipmentRepository.ReadEntities().ToList();

            cmbNewEquipment.ValueMember = "Id";
            cmbNewEquipment.DisplayMember = "DisplayText";  // Мы создадим анонимный тип с этим свойством

            var displayList = equipmentList.Select(eq => new
            {
                Id = eq.Id,
                DisplayText = $"{eq.Name} {eq.Model} (в наличии: {eq.Quantity} шт.)"
            }).ToList();

            cmbNewEquipment.DataSource = displayList;
        }

        private void RefreshItemsGrid()
        {
            // Создаём анонимный тип для отображения в гриде
            var displayList = _currentItems.Select(item =>
            {
                var eq = _equipmentRepository.ReadEntity(item.EquipmentId);
                return new
                {
                    EquipmentId = item.EquipmentId,
                    Name = eq?.Name ?? "Неизвестно",
                    Model = eq?.Model ?? "",
                    Price = eq?.Price ?? 0m,
                    Quantity = item.Quantity,
                    Sum = (eq?.Price ?? 0m) * item.Quantity
                };
            }).ToList();

            dgvSaleItems.DataSource = null; // сбрасываем, чтобы обновилось
            dgvSaleItems.DataSource = displayList;
            dgvSaleItems.AutoResizeColumns();
        }

        // Кнопка "Добавить"
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (cmbNewEquipment.SelectedValue == null)
            {
                MessageBox.Show("Выберите товар!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtNewQuantity.Text, out int qty) || qty <= 0)
            {
                MessageBox.Show("Введите корректное количество (положительное число)!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int equipmentId = (int)cmbNewEquipment.SelectedValue;

            // Проверяем наличие на складе
            var equipment = _equipmentRepository.ReadEntity(equipmentId);
            if (equipment == null || equipment.Quantity < qty)
            {
                MessageBox.Show("Недостаточно товара на складе!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Добавляем или увеличиваем количество
            var existing = _currentItems.FirstOrDefault(i => i.EquipmentId == equipmentId);
            if (existing != null)
            {
                existing = SaleItem.CreateItem(equipmentId, existing.Quantity + qty);
                _currentItems[_currentItems.IndexOf(_currentItems.First(i => i.EquipmentId == equipmentId))] = existing;
            }
            else
            {
                _currentItems.Add(SaleItem.CreateItem(equipmentId, qty));
            }

            txtNewQuantity.Text = "1";
            RefreshItemsGrid();
        }

        // Кнопка "Сохранить продажу"
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbSeller.SelectedValue == null || cmbClient.SelectedValue == null)
            {
                MessageBox.Show("Выберите продавца и клиента!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_currentItems.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы одну позицию в продажу!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int sellerId = (int)cmbSeller.SelectedValue;
            int clientId = (int)cmbClient.SelectedValue;

            Sale newSale = Sale.CreateOperation(0, sellerId, clientId, _currentItems);

            try
            {
                // 1. Уменьшаем количество на складе
                foreach (var item in _currentItems)
                {
                    var eq = _equipmentRepository.ReadEntity(item.EquipmentId);
                    if (eq != null)
                    {
                        var updated = Equipment.CreateEntity(
                            eq.Id,
                            eq.Name,
                            eq.Model,
                            eq.Price,
                            eq.Quantity - item.Quantity,
                            eq.Category
                        );
                        _equipmentRepository.UpdateEntity(updated);
                    }
                }

                // 2. Сохраняем продажу
                _saleRepository.CreateOperation(newSale);

                MessageBox.Show("Продажа успешно сохранена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении продажи:\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
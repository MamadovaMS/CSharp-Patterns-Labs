﻿namespace Lab4.Forms
{
    partial class FormSupply
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.ComboBox cmbSeller;
        private System.Windows.Forms.ComboBox cmbEquipment; // <-- ДОБАВЛЕНО
        private System.Windows.Forms.TextBox txtQuantity;    // <-- ДОБАВЛЕНО
        private System.Windows.Forms.DataGridView dgvSupplyItems;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Button btnDeleteItem;
        private System.Windows.Forms.Label lblSeller;
        private System.Windows.Forms.Label lblEquipment;    // <-- ДОБАВЛЕНО
        private System.Windows.Forms.Label lblQuantity;     // <-- ДОБАВЛЕНО
        private System.Windows.Forms.Label lblItems;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSeller = new System.Windows.Forms.ComboBox();
            this.dgvSupplyItems = new System.Windows.Forms.DataGridView();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.btnDeleteItem = new System.Windows.Forms.Button();
            this.lblSeller = new System.Windows.Forms.Label();
            this.lblItems = new System.Windows.Forms.Label();
            this.cmbEquipment = new System.Windows.Forms.ComboBox(); // <-- Инициализация
            this.lblEquipment = new System.Windows.Forms.Label();      // <-- Инициализация
            this.txtQuantity = new System.Windows.Forms.TextBox();    // <-- Инициализация
            this.lblQuantity = new System.Windows.Forms.Label();       // <-- Инициализация
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplyItems)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbSeller
            // 
            this.cmbSeller.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSeller.FormattingEnabled = true;
            this.cmbSeller.Location = new System.Drawing.Point(100, 10);
            this.cmbSeller.Name = "cmbSeller";
            this.cmbSeller.Size = new System.Drawing.Size(462, 21);
            this.cmbSeller.TabIndex = 0;
            // 
            // lblSeller
            // 
            this.lblSeller.AutoSize = true;
            this.lblSeller.Location = new System.Drawing.Point(10, 13);
            this.lblSeller.Name = "lblSeller";
            this.lblSeller.Size = new System.Drawing.Size(60, 13);
            this.lblSeller.TabIndex = 6;
            this.lblSeller.Text = "Продавец:";
            // 
            // cmbEquipment
            // 
            this.cmbEquipment.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbEquipment.FormattingEnabled = true;
            this.cmbEquipment.Location = new System.Drawing.Point(100, 40);
            this.cmbEquipment.Name = "cmbEquipment";
            this.cmbEquipment.Size = new System.Drawing.Size(260, 21);
            this.cmbEquipment.TabIndex = 1;
            // 
            // lblEquipment
            // 
            this.lblEquipment.AutoSize = true;
            this.lblEquipment.Location = new System.Drawing.Point(10, 43);
            this.lblEquipment.Name = "lblEquipment";
            this.lblEquipment.Size = new System.Drawing.Size(65, 13);
            this.lblEquipment.TabIndex = 7;
            this.lblEquipment.Text = "Оборудов.:";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(100, 70);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(75, 20);
            this.txtQuantity.TabIndex = 2;
            this.txtQuantity.Text = "1";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(10, 73);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(69, 13);
            this.lblQuantity.TabIndex = 8;
            this.lblQuantity.Text = "Количество:";
            // 
            // btnAddItem
            // 
            this.btnAddItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAddItem.Location = new System.Drawing.Point(404, 69);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(75, 23);
            this.btnAddItem.TabIndex = 3;
            this.btnAddItem.Text = "Добавить";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.AddItem_Click);
            // 
            // btnDeleteItem
            // 
            this.btnDeleteItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDeleteItem.Location = new System.Drawing.Point(485, 69);
            this.btnDeleteItem.Name = "btnDeleteItem";
            this.btnDeleteItem.Size = new System.Drawing.Size(75, 23);
            this.btnDeleteItem.TabIndex = 4;
            this.btnDeleteItem.Text = "Удалить";
            this.btnDeleteItem.UseVisualStyleBackColor = true;
            this.btnDeleteItem.Click += new System.EventHandler(this.DeleteItem_Click); // <-- ПРИВЯЗКА СОБЫТИЯ
            // 
            // lblItems
            // 
            this.lblItems.AutoSize = true;
            this.lblItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblItems.Location = new System.Drawing.Point(10, 105);
            this.lblItems.Name = "lblItems";
            this.lblItems.Size = new System.Drawing.Size(127, 13);
            this.lblItems.TabIndex = 9;
            this.lblItems.Text = "Товары в поставке:";
            // 
            // dgvSupplyItems
            // 
            this.dgvSupplyItems.AllowUserToAddRows = false;
            this.dgvSupplyItems.AllowUserToDeleteRows = false;
            this.dgvSupplyItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvSupplyItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSupplyItems.Location = new System.Drawing.Point(10, 125);
            this.dgvSupplyItems.Name = "dgvSupplyItems";
            this.dgvSupplyItems.ReadOnly = true;
            this.dgvSupplyItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSupplyItems.Size = new System.Drawing.Size(550, 160);
            this.dgvSupplyItems.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btnSave.Location = new System.Drawing.Point(235, 300);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // FormSupply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 342);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.lblEquipment);
            this.Controls.Add(this.cmbEquipment);
            this.Controls.Add(this.lblItems);
            this.Controls.Add(this.lblSeller);
            this.Controls.Add(this.btnDeleteItem);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dgvSupplyItems);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.cmbSeller);
            this.Name = "FormSupply";
            this.Text = "Создание операции поставки";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSupplyItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
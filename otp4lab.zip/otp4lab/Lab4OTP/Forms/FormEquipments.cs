﻿using System.Linq;
using System.Windows.Forms;
using Unity;
using Lab4.Repositories;
using System;

namespace Lab4.Forms
{
    public partial class FormEquipments : Form
    {
        private readonly IEquipmentRepository _equipmentRepository;
        private readonly IUnityContainer _container;

        public FormEquipments(IEquipmentRepository equipmentRepository, IUnityContainer container)
        {
            InitializeComponent();
            _equipmentRepository = equipmentRepository;
            _container = container;
            this.Text = "Список техники";
            LoadList();
        }

        private void LoadList()
        {
            try
            {
                dgvEquipments.DataSource = _equipmentRepository.ReadEntities().ToList();
                dgvEquipments.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка: " + ex.Message);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            try
            {
                var form = _container.Resolve<FormEquipment>();
                form.EquipmentId = 0; // Инициализация для создания

                // Если форма вернула DialogResult.OK (было сохранение)
                if (form.ShowDialog() == DialogResult.OK)
                {
                    LoadList(); // Перезагружаем список
                }
            }
            catch (Exception ex)
            {
                // Теперь вы увидите причину ошибки!
                MessageBox.Show("Ошибка при открытии формы добавления техники: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА ИЗМЕНИТЬ: Явная проверка выбора строки ***
            if (dgvEquipments.SelectedRows.Count == 0 || dgvEquipments.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите элемент для редактирования!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedId = (int)dgvEquipments.SelectedRows[0].Cells["Id"].Value;

            var form = _container.Resolve<FormEquipment>();
            form.EquipmentId = selectedId;
            if (form.ShowDialog() == DialogResult.OK) LoadList();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА УДАЛИТЬ: Явная проверка выбора строки ***
            if (dgvEquipments.SelectedRows.Count == 0 || dgvEquipments.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите элемент для удаления!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedId = (int)dgvEquipments.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Удалить выбранную технику?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    _equipmentRepository.DeleteEntity(selectedId);
                    LoadList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления: " + ex.Message);
                }
            }
        }
    }
}
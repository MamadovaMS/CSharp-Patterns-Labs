﻿using System.Linq;
using System.Windows.Forms;
using Unity;
using Lab4.Repositories;
using System;

namespace Lab4.Forms
{
    public partial class FormClients : Form
    {
        private readonly IClientRepository _clientRepository;
        private readonly IUnityContainer _container;

        public FormClients(IClientRepository clientRepository, IUnityContainer container)
        {
            InitializeComponent();
            _clientRepository = clientRepository;
            _container = container;
            this.Text = "Список клиентов";
            LoadList();
        }

        private void LoadList()
        {
            try
            {
                dgvClients.DataSource = _clientRepository.ReadEntities().ToList();
                dgvClients.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка: " + ex.Message);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА ДОБАВИТЬ
            var form = _container.Resolve<FormClient>();
            form.ClientId = 0; // Инициализация для создания

            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadList(); // Перезагружаем список
            }
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА ИЗМЕНИТЬ: Явная проверка выбора строки ***
            if (dgvClients.SelectedRows.Count == 0 || dgvClients.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите клиента для редактирования!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Получение ID из выбранной строки (столбец "Id" должен существовать)
            int selectedId = (int)dgvClients.SelectedRows[0].Cells["Id"].Value;

            var form = _container.Resolve<FormClient>();
            form.ClientId = selectedId; // Инициализация для редактирования

            if (form.ShowDialog() == DialogResult.OK)
            {
                LoadList(); // Перезагружаем список
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА УДАЛИТЬ: Явная проверка выбора строки ***
            if (dgvClients.SelectedRows.Count == 0 || dgvClients.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите клиента для удаления!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedId = (int)dgvClients.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Удалить выбранного клиента?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    _clientRepository.DeleteEntity(selectedId); // Вызов удаления
                    LoadList(); // Перезагружаем список
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления: " + ex.Message);
                }
            }
        }
    }
}
﻿using System;
using System.Windows.Forms;
using Lab4.Repositories;
using Lab4.Entities;
using Lab4.Entities.Enums;
using System.Linq;

namespace Lab4.Forms
{
    public partial class FormSeller : Form
    {
        private readonly ISellerRepository _sellerRepository;
        private int _sellerId;

        public FormSeller(ISellerRepository sellerRepository)
        {
            InitializeComponent();
            _sellerRepository = sellerRepository;

            // Заполняем ComboBox значениями перечисления
            cmbPost.DataSource = Enum.GetValues(typeof(SellerPost))
                                     .Cast<SellerPost>()
                                     .ToList();

            this.Text = "Создание/Редактирование продавца";
        }

        public int SellerId
        {
            set
            {
                _sellerId = value;
                if (_sellerId > 0)
                {
                    this.Text = "Изменение данных продавца";
                    LoadDataForEdit();
                }
                else
                {
                    this.Text = "Создание нового продавца";
                }
            }
        }

        private void LoadDataForEdit()
        {
            Seller seller = _sellerRepository.ReadEntity(_sellerId);
            if (seller != null)
            {
                txtFirstName.Text = seller.FirstName;
                txtLastName.Text = seller.LastName;
                txtLogin.Text = seller.Login;

                // Преобразуем строку из сущности обратно в enum для ComboBox
                if (Enum.TryParse<SellerPost>(seller.Position, out SellerPost post))
                {
                    cmbPost.SelectedItem = post;
                }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || cmbPost.SelectedItem == null)
            {
                MessageBox.Show("Заполните Имя и выберите Должность!",
                                "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Преобразуем выбранное значение enum в строку
            string position = ((SellerPost)cmbPost.SelectedItem).ToString();

            Seller newOrUpdatedSeller = Seller.CreateEntity(
                _sellerId,
                txtFirstName.Text.Trim(),
                txtLastName.Text.Trim(),
                txtLogin.Text.Trim(),
                position   // string, а не enum
            );

            try
            {
                if (_sellerId == 0)
                {
                    _sellerRepository.CreateEntity(newOrUpdatedSeller);
                }
                else
                {
                    _sellerRepository.UpdateEntity(newOrUpdatedSeller);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения данных продавца: " + ex.Message,
                                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
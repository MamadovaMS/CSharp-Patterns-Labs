﻿using System.Linq;
using System.Windows.Forms;
using Unity;
using Lab4.Repositories;
using System;

namespace Lab4.Forms
{
    public partial class FormSupplies : Form
    {
        private readonly ISupplyRepository _supplyRepository;
        private readonly IUnityContainer _container;

        public FormSupplies(ISupplyRepository supplyRepository, IUnityContainer container)
        {
            InitializeComponent();
            _supplyRepository = supplyRepository;
            _container = container;
            this.Text = "Список операций поступления";
            LoadList();
        }

        private void LoadList()
        {
            try
            {
                dgvSupplies.DataSource = _supplyRepository.ReadOperations().ToList();
                dgvSupplies.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка: " + ex.Message);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var form = _container.Resolve<FormSupply>();
            if (form.ShowDialog() == DialogResult.OK) LoadList();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            // Операции не редактируются
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (dgvSupplies.SelectedRows.Count == 0 || dgvSupplies.SelectedRows[0].Cells["Id"].Value == null) return;
            int selectedId = (int)dgvSupplies.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Удалить операцию поступления?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    _supplyRepository.DeleteOperation(selectedId);
                    LoadList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления: " + ex.Message);
                }
            }
        }
    }
}
﻿using System.Linq;
using System.Windows.Forms;
using Unity;
using Lab4.Repositories;
using System;

namespace Lab4.Forms
{
    public partial class FormSellers : Form
    {
        private readonly ISellerRepository _sellerRepository;
        private readonly IUnityContainer _container;

        // DI: Получение репозитория и контейнера
        public FormSellers(ISellerRepository sellerRepository, IUnityContainer container)
        {
            InitializeComponent();
            _sellerRepository = sellerRepository;
            _container = container;
            this.Text = "Список продавцов";
            LoadList();
        }

        private void LoadList()
        {
            try
            {
                dgvSellers.DataSource = _sellerRepository.ReadEntities().ToList();
                dgvSellers.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка: " + ex.Message);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА ДОБАВИТЬ: Здесь проблема маловероятна, если DI настроен правильно.
            var form = _container.Resolve<FormSeller>();
            form.SellerId = 0; // Режим создания
            if (form.ShowDialog() == DialogResult.OK) LoadList();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА ИЗМЕНИТЬ: Явная проверка выбора строки ***
            if (dgvSellers.SelectedRows.Count == 0 || dgvSellers.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите продавца для редактирования!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Получаем ID выбранной сущности
            int selectedId = (int)dgvSellers.SelectedRows[0].Cells["Id"].Value;

            var form = _container.Resolve<FormSeller>();
            form.SellerId = selectedId; // Режим редактирования
            if (form.ShowDialog() == DialogResult.OK) LoadList();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            // *** КНОПКА УДАЛИТЬ: Явная проверка выбора строки ***
            if (dgvSellers.SelectedRows.Count == 0 || dgvSellers.SelectedRows[0].Cells["Id"].Value == null)
            {
                MessageBox.Show("Выберите продавца для удаления!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedId = (int)dgvSellers.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Удалить выбранного продавца?", "Подтверждение", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    _sellerRepository.DeleteEntity(selectedId);
                    LoadList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка удаления: " + ex.Message);
                }
            }
        }
    }
}
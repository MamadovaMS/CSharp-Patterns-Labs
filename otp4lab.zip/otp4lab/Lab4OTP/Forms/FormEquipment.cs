﻿using System;
using System.Windows.Forms;
using Lab4.Repositories;
using Lab4.Entities;
using Lab4.Entities.Enums;
using System.Linq;

namespace Lab4.Forms
{
    public partial class FormEquipment : Form
    {
        private readonly IEquipmentRepository _equipmentRepository;
        private int _equipmentId;

        public FormEquipment(IEquipmentRepository equipmentRepository)
        {
            InitializeComponent();
            _equipmentRepository = equipmentRepository;
            this.Text = "Создание/Редактирование техники";

            // Заполняем ComboBox значениями перечисления
            cmbCategory.DataSource = Enum.GetValues(typeof(EquipmentCategory))
                                         .Cast<EquipmentCategory>()
                                         .ToList();
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList; // Чтобы нельзя было вводить вручную
        }

        public int EquipmentId
        {
            set
            {
                _equipmentId = value;
                if (_equipmentId > 0) LoadDataForEdit();
            }
        }

        private void LoadDataForEdit()
        {
            Equipment equipment = _equipmentRepository.ReadEntity(_equipmentId);
            if (equipment != null)
            {
                txtName.Text = equipment.Name;
                txtModel.Text = equipment.Model;
                txtPrice.Text = equipment.Price.ToString();
                txtQuantity.Text = equipment.Quantity.ToString();

                // Преобразуем строку из сущности обратно в enum для ComboBox
                if (Enum.TryParse<EquipmentCategory>(equipment.Category, out EquipmentCategory category))
                {
                    cmbCategory.SelectedItem = category;
                }
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            decimal price = 0;
            int quantity = 0;

            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                cmbCategory.SelectedItem == null ||
                !decimal.TryParse(txtPrice.Text, out price) ||
                !int.TryParse(txtQuantity.Text, out quantity) ||
                price < 0 || quantity < 0)
            {
                MessageBox.Show("Введите корректное Название, выберите Категорию, и убедитесь, что Цена и Количество — положительные числа!",
                                "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Преобразуем выбранный enum в строку
            string category = ((EquipmentCategory)cmbCategory.SelectedItem).ToString();

            // Создание объекта сущности
            Equipment newOrUpdatedEquipment = Equipment.CreateEntity(
                _equipmentId,
                txtName.Text.Trim(),
                txtModel.Text.Trim(),
                price,
                quantity,
                category  // string, а не enum
            );

            try
            {
                if (_equipmentId == 0)
                {
                    _equipmentRepository.CreateEntity(newOrUpdatedEquipment);
                }
                else
                {
                    _equipmentRepository.UpdateEntity(newOrUpdatedEquipment);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения данных техники: " + ex.Message,
                                "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
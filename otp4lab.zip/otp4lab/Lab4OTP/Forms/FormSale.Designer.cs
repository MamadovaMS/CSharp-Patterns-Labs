﻿namespace Lab4.Forms
{
    partial class FormSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSeller = new System.Windows.Forms.ComboBox();
            this.cmbClient = new System.Windows.Forms.ComboBox();
            this.dgvSaleItems = new System.Windows.Forms.DataGridView();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblSeller = new System.Windows.Forms.Label();
            this.lblClient = new System.Windows.Forms.Label();
            this.lblItems = new System.Windows.Forms.Label();

            // Новые контролы для добавления позиции
            this.cmbNewEquipment = new System.Windows.Forms.ComboBox();
            this.txtNewQuantity = new System.Windows.Forms.TextBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.lblNewEquipment = new System.Windows.Forms.Label();
            this.lblNewQuantity = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvSaleItems)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbSeller
            // 
            this.cmbSeller.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeller.FormattingEnabled = true;
            this.cmbSeller.Location = new System.Drawing.Point(120, 12);
            this.cmbSeller.Name = "cmbSeller";
            this.cmbSeller.Size = new System.Drawing.Size(200, 21);
            this.cmbSeller.TabIndex = 0;
            // 
            // cmbClient
            // 
            this.cmbClient.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClient.FormattingEnabled = true;
            this.cmbClient.Location = new System.Drawing.Point(120, 42);
            this.cmbClient.Name = "cmbClient";
            this.cmbClient.Size = new System.Drawing.Size(200, 21);
            this.cmbClient.TabIndex = 1;
            // 
            // dgvSaleItems
            // 
            this.dgvSaleItems.AllowUserToAddRows = false;
            this.dgvSaleItems.AllowUserToDeleteRows = false;
            this.dgvSaleItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSaleItems.Location = new System.Drawing.Point(12, 100);
            this.dgvSaleItems.Name = "dgvSaleItems";
            this.dgvSaleItems.ReadOnly = true;
            this.dgvSaleItems.RowHeadersVisible = false;
            this.dgvSaleItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSaleItems.Size = new System.Drawing.Size(540, 200);
            this.dgvSaleItems.TabIndex = 2;
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(420, 350);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(120, 35);
            this.btnSave.TabIndex = 3;
            this.btnSave.Text = "Сохранить продажу";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // lblSeller
            // 
            this.lblSeller.AutoSize = true;
            this.lblSeller.Location = new System.Drawing.Point(12, 15);
            this.lblSeller.Name = "lblSeller";
            this.lblSeller.Size = new System.Drawing.Size(85, 13);
            this.lblSeller.TabIndex = 4;
            this.lblSeller.Text = "Продавец:";
            // 
            // lblClient
            // 
            this.lblClient.AutoSize = true;
            this.lblClient.Location = new System.Drawing.Point(12, 45);
            this.lblClient.Name = "lblClient";
            this.lblClient.Size = new System.Drawing.Size(55, 13);
            this.lblClient.TabIndex = 5;
            this.lblClient.Text = "Клиент:";
            // 
            // lblItems
            // 
            this.lblItems.AutoSize = true;
            this.lblItems.Location = new System.Drawing.Point(12, 80);
            this.lblItems.Name = "lblItems";
            this.lblItems.Size = new System.Drawing.Size(120, 13);
            this.lblItems.TabIndex = 6;
            this.lblItems.Text = "Позиции продажи:";
            // 
            // cmbNewEquipment
            // 
            this.cmbNewEquipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbNewEquipment.FormattingEnabled = true;
            this.cmbNewEquipment.Location = new System.Drawing.Point(350, 12);
            this.cmbNewEquipment.Name = "cmbNewEquipment";
            this.cmbNewEquipment.Size = new System.Drawing.Size(200, 21);
            this.cmbNewEquipment.TabIndex = 7;
            // 
            // txtNewQuantity
            // 
            this.txtNewQuantity.Location = new System.Drawing.Point(350, 42);
            this.txtNewQuantity.Name = "txtNewQuantity";
            this.txtNewQuantity.Size = new System.Drawing.Size(100, 20);
            this.txtNewQuantity.TabIndex = 8;
            this.txtNewQuantity.Text = "1";
            this.txtNewQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(460, 38);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(90, 28);
            this.btnAddItem.TabIndex = 9;
            this.btnAddItem.Text = "Добавить →";
            this.btnAddItem.UseVisualStyleBackColor = true;
            // 
            // lblNewEquipment
            // 
            this.lblNewEquipment.AutoSize = true;
            this.lblNewEquipment.Location = new System.Drawing.Point(347, -4); // чуть выше ComboBox
            this.lblNewEquipment.Name = "lblNewEquipment";
            this.lblNewEquipment.Size = new System.Drawing.Size(100, 13);
            this.lblNewEquipment.TabIndex = 10;
            this.lblNewEquipment.Text = "Добавить товар:";
            // 
            // lblNewQuantity
            // 
            this.lblNewQuantity.AutoSize = true;
            this.lblNewQuantity.Location = new System.Drawing.Point(347, 45);
            this.lblNewQuantity.Name = "lblNewQuantity";
            this.lblNewQuantity.Size = new System.Drawing.Size(69, 13);
            this.lblNewQuantity.TabIndex = 11;
            this.lblNewQuantity.Text = "Количество:";
            // 
            // FormSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(570, 400);
            this.Controls.Add(this.lblNewQuantity);
            this.Controls.Add(this.lblNewEquipment);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.txtNewQuantity);
            this.Controls.Add(this.cmbNewEquipment);
            this.Controls.Add(this.lblItems);
            this.Controls.Add(this.lblClient);
            this.Controls.Add(this.lblSeller);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dgvSaleItems);
            this.Controls.Add(this.cmbClient);
            this.Controls.Add(this.cmbSeller);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "FormSale";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Создание операции продажи";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSaleItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSeller;
        private System.Windows.Forms.ComboBox cmbClient;
        private System.Windows.Forms.DataGridView dgvSaleItems;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblSeller;
        private System.Windows.Forms.Label lblClient;
        private System.Windows.Forms.Label lblItems;

        // Новые контролы
        private System.Windows.Forms.ComboBox cmbNewEquipment;
        private System.Windows.Forms.TextBox txtNewQuantity;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.Label lblNewEquipment;
        private System.Windows.Forms.Label lblNewQuantity;
    }
}
﻿namespace Lab4.Forms
{
    partial class FormSeller
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.ComboBox cmbPost;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.Label lblPost;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows 
        // или #region Windows Form Designer generated code (в зависимости от языка VS)

        private void InitializeComponent()
        {
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.cmbPost = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblLogin = new System.Windows.Forms.Label();
            this.lblPost = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(100, 10);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(200, 20);
            this.txtFirstName.TabIndex = 0;
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(10, 13);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Text = "Имя:";
            // 
            // txtLastName
            // (Добавлены недостающие настройки)
            this.txtLastName.Location = new System.Drawing.Point(100, 40);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(200, 20);
            this.txtLastName.TabIndex = 1;
            //
            // lblLastName
            // (Добавлены недостающие настройки)
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(10, 43);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Text = "Фамилия:";
            //
            // txtLogin
            // (Добавлены недостающие настройки)
            this.txtLogin.Location = new System.Drawing.Point(100, 70);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(200, 20);
            this.txtLogin.TabIndex = 2;
            //
            // lblLogin
            // (Добавлены недостающие настройки)
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(10, 73);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Text = "Логин:";
            // 
            // cmbPost
            // 
            this.cmbPost.FormattingEnabled = true;
            this.cmbPost.Location = new System.Drawing.Point(100, 100);
            this.cmbPost.Name = "cmbPost";
            this.cmbPost.Size = new System.Drawing.Size(200, 21);
            this.cmbPost.TabIndex = 3;
            // 
            // lblPost
            // (Добавлены недостающие настройки)
            this.lblPost.AutoSize = true;
            this.lblPost.Location = new System.Drawing.Point(10, 103);
            this.lblPost.Name = "lblPost";
            this.lblPost.Text = "Должность:";
            //
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(100, 140);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 25);
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // FormSeller
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 178);
            this.Controls.Add(this.lblPost);
            this.Controls.Add(this.lblLogin);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cmbPost);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.lblFirstName);
            this.Name = "FormSeller";
            this.Text = "Редактирование продавца";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion 
    }
}
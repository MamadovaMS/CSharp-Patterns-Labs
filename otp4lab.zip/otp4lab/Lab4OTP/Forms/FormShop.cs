﻿using System.Windows.Forms;
using Unity;
using System;
using System.Drawing;

namespace Lab4.Forms
{
    public partial class FormShop : Form
    {
        private readonly IUnityContainer _container;

        public FormShop(IUnityContainer container)
        {
            _container = container;
            this.Text = "Система учета продаж компьютерной техники";
            this.Size = new Size(250, 220);

            int yPos = 10;
            const int step = 30;

            Button btnSellers = new Button { Text = "Продавцы", Location = new Point(10, yPos), Width = 200 };
            btnSellers.Click += (s, e) => OpenForm<FormSellers>();
            this.Controls.Add(btnSellers);
            yPos += step;

            Button btnClients = new Button { Text = "Клиенты", Location = new Point(10, yPos), Width = 200 };
            btnClients.Click += (s, e) => OpenForm<FormClients>();
            this.Controls.Add(btnClients);
            yPos += step;

            Button btnEquipments = new Button { Text = "Техника", Location = new Point(10, yPos), Width = 200 };
            btnEquipments.Click += (s, e) => OpenForm<FormEquipments>();
            this.Controls.Add(btnEquipments);
            yPos += step;

            Button btnSupplies = new Button { Text = "Поступления", Location = new Point(10, yPos), Width = 200 };
            btnSupplies.Click += (s, e) => OpenForm<FormSupplies>();
            this.Controls.Add(btnSupplies);
            yPos += step;

            Button btnSales = new Button { Text = "Продажи", Location = new Point(10, yPos), Width = 200 };
            btnSales.Click += (s, e) => OpenForm<FormSales>();
            this.Controls.Add(btnSales);
        }

        private void OpenForm<TForm>() where TForm : Form
        {
            try
            {
                using (var form = _container.Resolve<TForm>())
                {
                    form.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка открытия формы: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
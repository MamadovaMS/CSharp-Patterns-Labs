﻿using System.Windows.Forms;
using Lab4.Repositories;
using Lab4.Entities;
using System.Collections.Generic;
using System.Linq;
using System;

namespace Lab4.Forms
{
    public partial class FormSupply : Form
    {
        // Репозитории, внедряемые через DI
        private readonly ISupplyRepository _supplyRepository;
        private readonly IEquipmentRepository _equipmentRepository;
        private readonly ISellerRepository _sellerRepository;

        // Список для временного хранения добавляемых позиций
        private List<SupplyItem> currentItems = new List<SupplyItem>();

        public FormSupply(ISupplyRepository supplyRepository, IEquipmentRepository equipmentRepository, ISellerRepository sellerRepository)
        {
            InitializeComponent();
            _supplyRepository = supplyRepository;
            _equipmentRepository = equipmentRepository;
            _sellerRepository = sellerRepository;
            this.Text = "Создание операции поставки";

            LoadComboBoxes();
            RefreshItemsGrid(); // Инициализация DataGridView
        }

        private void LoadComboBoxes()
        {
            try
            {
                // Загрузка Продавцов
                cmbSeller.DataSource = _sellerRepository.ReadEntities().Select(s => new { s.Id, FullName = $"{s.FirstName} {s.LastName}" }).ToList();
                cmbSeller.DisplayMember = "FullName";
                cmbSeller.ValueMember = "Id";

                // Загрузка Оборудования
                // Для поставки нам нужно все оборудование, которое мы можем поставлять
                cmbEquipment.DataSource = _equipmentRepository.ReadEntities().Select(e => new { e.Id, DisplayName = $"{e.Name} ({e.Model})" }).ToList();
                cmbEquipment.DisplayMember = "DisplayName";
                cmbEquipment.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных для ComboBox'ов: " + ex.Message);
            }
        }

        // Обновляет DataGridView с текущим списком товаров
        private void RefreshItemsGrid()
        {
            // Получаем список товаров из репозитория для отображения их названий, 
            // так как в SupplyItem хранятся только EquipmentId и Quantity
            var allEquipment = _equipmentRepository.ReadEntities().ToDictionary(e => e.Id, e => e);

            dgvSupplyItems.DataSource = null;
            dgvSupplyItems.DataSource = currentItems.Select(item => new
            {
                // Отображаем название, а не только ID
                EquipmentName = allEquipment.ContainsKey(item.EquipmentId) ? allEquipment[item.EquipmentId].Name : $"ID {item.EquipmentId} (Не найдено)",
                item.Quantity,
                item.EquipmentId // Оставляем для возможного использования, но не обязательно отображаем
            }).ToList();

            // Скрываем ID в списке, если он не нужен пользователю
            if (dgvSupplyItems.Columns.Contains("EquipmentId"))
            {
                dgvSupplyItems.Columns["EquipmentId"].Visible = false;
            }
            dgvSupplyItems.AutoResizeColumns();
        }

        private void AddItem_Click(object sender, EventArgs e)
        {
            if (cmbEquipment.SelectedValue == null || !int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Необходимо выбрать оборудование и ввести корректное количество (> 0)!");
                return;
            }

            int equipmentId = (int)cmbEquipment.SelectedValue;

            // Проверяем, есть ли уже этот товар в списке
            var existingItem = currentItems.FirstOrDefault(item => item.EquipmentId == equipmentId);

            if (existingItem != null)
            {
                // Если товар уже есть, обновляем количество
                // NOTE: В классе SupplyItem поля Quantity приватные (private set), поэтому нужно создать новый объект
                currentItems.Remove(existingItem);
                currentItems.Add(SupplyItem.CreateItem(equipmentId, existingItem.Quantity + quantity));
            }
            else
            {
                // Если товара нет, добавляем новый
                currentItems.Add(SupplyItem.CreateItem(equipmentId, quantity));
            }

            // Очищаем поле количества для следующего ввода
            txtQuantity.Text = "1";
            RefreshItemsGrid();
        }

        // <-- МЕТОД, КОТОРЫЙ ОТСУТСТВОВАЛ И ВЫЗЫВАЛ ОШИБКУ
        private void DeleteItem_Click(object sender, EventArgs e)
        {
            if (dgvSupplyItems.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите товар для удаления.");
                return;
            }

            // Получаем ID оборудования из выбранной строки (нужно убедиться, что столбец EquipmentId существует и не скрыт)
            if (dgvSupplyItems.SelectedRows[0].Cells["EquipmentId"].Value is int selectedEquipmentId)
            {
                var itemToRemove = currentItems.FirstOrDefault(item => item.EquipmentId == selectedEquipmentId);
                if (itemToRemove != null)
                {
                    currentItems.Remove(itemToRemove);
                    RefreshItemsGrid();
                }
            }
            else
            {
                MessageBox.Show("Ошибка: Не удалось определить ID выбранного товара.");
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            if (cmbSeller.SelectedValue == null || currentItems.Count == 0)
            {
                MessageBox.Show("Необходимо выбрать продавца и добавить хотя бы один товар!");
                return;
            }

            int sellerId = (int)cmbSeller.SelectedValue;

            // Создаем новую операцию поставки (ID=0 - будет присвоен в репозитории)
            Supply newSupply = Supply.CreateOperation(id: 0, sellerId, currentItems);

            try
            {
                _supplyRepository.CreateOperation(newSupply);
                MessageBox.Show("Операция поставки успешно сохранена!");
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения операции: " + ex.Message);
            }
        }
    }
}
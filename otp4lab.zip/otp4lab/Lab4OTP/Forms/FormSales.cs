﻿using System.Linq;
using System.Windows.Forms;
using Unity;
using Lab4.Repositories;
using System;

namespace Lab4.Forms
{
    public partial class FormSales : Form
    {
        private readonly ISaleRepository _saleRepository;
        private readonly IUnityContainer _container;

        public FormSales(ISaleRepository saleRepository, IUnityContainer container)
        {
            InitializeComponent();
            _saleRepository = saleRepository;
            _container = container;
            this.Text = "Список операций продажи";
            LoadList();
        }

        private void LoadList()
        {
            try
            {
                dgvSales.DataSource = _saleRepository.ReadOperations().ToList();
                dgvSales.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка: " + ex.Message);
            }
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var form = _container.Resolve<FormSale>();
            if (form.ShowDialog() == DialogResult.OK) LoadList();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            // Операции не редактируются
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            // Операции обычно не удаляются
        }
    }
}
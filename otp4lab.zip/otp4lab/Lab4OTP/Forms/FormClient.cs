﻿using System.Windows.Forms;
using Lab4.Repositories;
using Lab4.Entities;
using System;

namespace Lab4.Forms
{
    public partial class FormClient : Form
    {
        private readonly IClientRepository _clientRepository;
        private int _clientId;

        public FormClient(IClientRepository clientRepository)
        {
            InitializeComponent();
            _clientRepository = clientRepository;
            this.Text = "Создание/Редактирование клиента";
        }

        public int ClientId
        {
            set
            {
                _clientId = value;
                if (_clientId > 0) LoadDataForEdit();
            }
        }

        private void LoadDataForEdit()
        {
            Client client = _clientRepository.ReadEntity(_clientId);
            if (client != null)
            {
                txtFirstName.Text = client.FirstName;
                txtLastName.Text = client.LastName;
                txtPhone.Text = client.Phone;
                txtEmail.Text = client.Email;
            }
        }


        private void SaveButton_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtFirstName.Text) || string.IsNullOrWhiteSpace(txtPhone.Text))
            {
                MessageBox.Show("Заполните Имя и Телефон клиента!", "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            Client newOrUpdatedClient = Client.CreateEntity(
                _clientId,
                txtFirstName.Text,
                txtLastName.Text,
                txtPhone.Text,
                txtEmail.Text
            );

            try
            {

                if (_clientId == 0) // Режим создания
                {
                    _clientRepository.CreateEntity(newOrUpdatedClient);
                }
                else // Режим редактирования
                {
                    _clientRepository.UpdateEntity(newOrUpdatedClient);
                }


                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Ошибка сохранения данных клиента: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
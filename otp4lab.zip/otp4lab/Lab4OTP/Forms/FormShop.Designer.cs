﻿namespace Lab4.Forms
{
    partial class FormShop
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FormShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(234, 181); // Примерный размер
            this.Name = "FormShop";
            this.Text = "FormShop";
            this.ResumeLayout(false);

        }

        #endregion
        // Кнопки здесь не определены, так как создаются в FormShop.cs
    }
}
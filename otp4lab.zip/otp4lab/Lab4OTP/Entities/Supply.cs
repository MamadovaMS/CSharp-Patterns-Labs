﻿using System;
using System.Collections.Generic;

namespace Lab4.Entities
{
    public class Supply
    {
        public int Id { get; private set; }
        public DateTime Date { get; private set; }
        public int SellerId { get; private set; }
        public List<SupplyItem> Items { get; set; } = new List<SupplyItem>();  

        public Supply() { }  

        public static Supply CreateOperation(int id, int sellerId, List<SupplyItem> items)
        {
            return new Supply
            {
                Id = id,
                Date = DateTime.Now,
                SellerId = sellerId,
                Items = items ?? new List<SupplyItem>()
            };
        }
    }
}
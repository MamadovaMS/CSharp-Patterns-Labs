﻿namespace Lab4.Entities
{
    public class SupplyItem
    {
        public int SupplyId { get; private set; }
        public int EquipmentId { get; private set; }
        public int Quantity { get; private set; }

        private SupplyItem() { }

        public static SupplyItem CreateItem(int equipmentId, int quantity)
        {
            return new SupplyItem
            {
                EquipmentId = equipmentId,
                Quantity = quantity
            };
        }
    }
}
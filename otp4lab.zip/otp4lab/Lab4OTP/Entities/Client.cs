﻿namespace Lab4.Entities
{
    public class Client
    {
        public int Id { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Phone { get; private set; }
        public string Email { get; private set; }

        private Client(int id, string firstName, string lastName, string phone, string email)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Phone = phone;
            Email = email;
        }

        public static Client CreateEntity(int id, string firstName, string lastName, string phone, string email = "")
        {
            return new Client(id, firstName, lastName, phone, email);
        }
    }
}
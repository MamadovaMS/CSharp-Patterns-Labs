﻿namespace Lab4.Entities
{
    public class Seller
    {
        public int Id { get; private set; }
        public string FirstName { get; private set; }
        public string LastName { get; private set; }
        public string Login { get; private set; }
        public string Position { get; private set; }

        private Seller(int id, string firstName, string lastName, string login, string position)
        {
            Id = id;
            FirstName = firstName;
            LastName = lastName;
            Login = login;
            Position = position;
        }

        public static Seller CreateEntity(int id, string firstName, string lastName, string login, string position)
        {
            return new Seller(id, firstName, lastName, login, position);
        }
    }
}
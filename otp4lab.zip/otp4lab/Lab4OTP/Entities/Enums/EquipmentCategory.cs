﻿namespace Lab4.Entities.Enums
{
    public enum EquipmentCategory
    {
        Laptop,
        Desktop,
        Monitor,
        Peripheral,
        Software
    }
}
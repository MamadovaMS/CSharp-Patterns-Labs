﻿namespace Lab4.Entities.Enums;

public enum SellerPost
{
    Consultant,
    Manager,
    Head
}
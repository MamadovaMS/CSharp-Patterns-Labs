﻿using System;

namespace Lab4.Entities.Enums
{
    [Flags]
    public enum EquipmentType
    {
        None = 0,
        Desktop = 1,
        Laptop = 2,
        Monitor = 4,
        Component = 8
    }
}
﻿using System;
using System.Collections.Generic;

namespace Lab4.Entities
{
    public class Sale
    {
        public int Id { get; private set; }
        public DateTime Date { get; private set; }
        public int SellerId { get; private set; }
        public int ClientId { get; private set; }
        public List<SaleItem> Items { get; set; } = new List<SaleItem>();  

        public Sale() { }  

        private Sale(int id, DateTime date, int sellerId, int clientId, List<SaleItem> items)
        {
            Id = id;
            Date = date;
            SellerId = sellerId;
            ClientId = clientId;
            Items = items ?? new List<SaleItem>();
        }

        public static Sale CreateOperation(int id, int sellerId, int clientId, List<SaleItem> items)
        {
            return new Sale(id, DateTime.Now, sellerId, clientId, items);
        }
    }
}
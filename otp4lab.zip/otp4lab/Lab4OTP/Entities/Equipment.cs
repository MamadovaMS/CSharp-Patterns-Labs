﻿namespace Lab4.Entities
{
    public class Equipment
    {
        public int Id { get; private set; }
        public string Name { get; private set; }
        public string Model { get; private set; }
        public decimal Price { get; private set; }
        public int Quantity { get; private set; }
        public string Category { get; private set; }

        private Equipment(int id, string name, string model, decimal price, int quantity, string category)
        {
            Id = id;
            Name = name;
            Model = model;
            Price = price;
            Quantity = quantity;
            Category = category;
        }

        public static Equipment CreateEntity(int id, string name, string model, decimal price, int quantity, string category) => new Equipment(id, name, model, price, quantity, category);
    }
}
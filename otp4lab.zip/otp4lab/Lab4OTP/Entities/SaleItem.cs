﻿namespace Lab4.Entities
{
    public class SaleItem
    {
        public int EquipmentId { get; private set; }
        public int Quantity { get; private set; }

        private SaleItem(int equipmentId, int quantity)
        {
            EquipmentId = equipmentId;
            Quantity = quantity;
        }

        public static SaleItem CreateItem(int equipmentId, int quantity)
        {
            return new SaleItem(equipmentId, quantity);
        }
    }
}
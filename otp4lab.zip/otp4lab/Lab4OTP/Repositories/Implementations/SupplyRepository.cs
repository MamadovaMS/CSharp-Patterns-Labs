﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using Lab4.Entities;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Lab4.Repositories.Implementations
{
    internal class SupplyRepository : ISupplyRepository
    {
        private readonly IConnectionString _connectionString;
        private readonly ILogger<SupplyRepository> _logger;

        public SupplyRepository(IConnectionString connectionString, ILogger<SupplyRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public void CreateOperation(Supply supply)
        {
            _logger.LogInformation("Создание операции поступления");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(supply));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Open();
                using var transaction = connection.BeginTransaction();

                var insertSupply = @"INSERT INTO Supplies (Date, SellerId) 
                                     VALUES (@Date, @SellerId) RETURNING Id";
                var supplyId = connection.QueryFirst<int>(insertSupply, supply, transaction);

                var insertItem = @"INSERT INTO SupplyItems (SupplyId, EquipmentId, Quantity) 
                                   VALUES (@SupplyId, @EquipmentId, @Quantity)";
                foreach (var item in supply.Items)
                {
                    connection.Execute(insertItem, new { SupplyId = supplyId, item.EquipmentId, item.Quantity }, transaction);
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка создания операции поступления");
                throw;
            }
        }

        public IEnumerable<Supply> ReadOperations(DateTime? dateFrom = null, DateTime? dateTo = null, int? sellerId = null)
        {
            _logger.LogInformation("Чтение операций поступлений");

            var sql = "SELECT * FROM Supplies WHERE 1=1";
            var parameters = new DynamicParameters();

            if (dateFrom.HasValue)
            {
                sql += " AND Date >= @DateFrom";
                parameters.Add("DateFrom", dateFrom.Value);
            }
            if (dateTo.HasValue)
            {
                sql += " AND Date <= @DateTo";
                parameters.Add("DateTo", dateTo.Value);
            }
            if (sellerId.HasValue)
            {
                sql += " AND SellerId = @SellerId";
                parameters.Add("SellerId", sellerId.Value);
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var supplies = connection.Query<Supply>(sql, parameters);
                foreach (var s in supplies)
                {
                    s.Items = connection.Query<SupplyItem>("SELECT EquipmentId, Quantity FROM SupplyItems WHERE SupplyId = @SupplyId", new { SupplyId = s.Id }).ToList();
                }
                return supplies;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения операций поступлений");
                throw;
            }
        }

        public Supply? ReadOperation(int id)
        {
            _logger.LogInformation("Чтение операции поступления по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var supply = connection.QueryFirstOrDefault<Supply>("SELECT * FROM Supplies WHERE Id = @Id", new { Id = id });
                if (supply != null)
                {
                    supply.Items = connection.Query<SupplyItem>("SELECT EquipmentId, Quantity FROM SupplyItems WHERE SupplyId = @SupplyId", new { SupplyId = id }).ToList();
                }
                return supply;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения операции поступления");
                throw;
            }
        }

        public void DeleteOperation(int id)
        {
            _logger.LogInformation("Удаление операции поступления по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Open();
                using var transaction = connection.BeginTransaction();

                connection.Execute("DELETE FROM SupplyItems WHERE SupplyId = @Id", new { Id = id }, transaction);
                connection.Execute("DELETE FROM Supplies WHERE Id = @Id", new { Id = id }, transaction);

                transaction.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка удаления операции поступления");
                throw;
            }
        }
    }
}
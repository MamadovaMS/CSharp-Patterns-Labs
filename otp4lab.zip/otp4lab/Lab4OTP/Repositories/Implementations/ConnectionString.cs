﻿using Microsoft.Extensions.Configuration;

namespace Lab4.Repositories.Implementations
{
    internal class ConnectionString : IConnectionString
    {
        public string Value { get; }

        public ConnectionString(IConfiguration configuration)
        {
            Value = configuration.GetConnectionString("DefaultConnection")
                    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Dapper;
using Lab4.Entities;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Lab4.Repositories.Implementations
{
    internal class SellerRepository : ISellerRepository
    {
        private readonly IConnectionString _connectionString;
        private readonly ILogger<SellerRepository> _logger;

        public SellerRepository(IConnectionString connectionString, ILogger<SellerRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public void CreateEntity(Seller entity)
        {
            _logger.LogInformation("Создание продавца");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"INSERT INTO Sellers (FirstName, LastName, Login, Position) 
                              VALUES (@FirstName, @LastName, @Login, @Position) RETURNING Id";
                connection.QueryFirst<int>(query, entity);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка создания продавца");
                throw;
            }
        }

        public Seller? ReadEntity(int id)
        {
            _logger.LogInformation("Чтение продавца по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                return connection.QueryFirstOrDefault<Seller>("SELECT * FROM Sellers WHERE Id = @Id", new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения продавца");
                throw;
            }
        }

        public IEnumerable<Seller> ReadEntities()
        {
            _logger.LogInformation("Чтение всех продавцов");

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                return connection.Query<Seller>("SELECT * FROM Sellers");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения продавцов");
                throw;
            }
        }

        public void UpdateEntity(Seller entity)
        {
            _logger.LogInformation("Обновление продавца");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"UPDATE Sellers SET FirstName = @FirstName, LastName = @LastName, 
                              Login = @Login, Position = @Position WHERE Id = @Id";
                connection.Execute(query, entity);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка обновления продавца");
                throw;
            }
        }

        public void DeleteEntity(int id)
        {
            _logger.LogInformation("Удаление продавца по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Execute("DELETE FROM Sellers WHERE Id = @Id", new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка удаления продавца");
                throw;
            }
        }
    }
}
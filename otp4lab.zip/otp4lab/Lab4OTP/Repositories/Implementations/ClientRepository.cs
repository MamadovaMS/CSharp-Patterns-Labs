﻿using System;
using System.Collections.Generic;
using Dapper;
using Lab4.Entities;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Lab4.Repositories.Implementations
{
    internal class ClientRepository : IClientRepository
    {
        private readonly IConnectionString _connectionString;
        private readonly ILogger<ClientRepository> _logger;

        public ClientRepository(IConnectionString connectionString, ILogger<ClientRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public void CreateEntity(Client entity)
        {
            _logger.LogInformation("Создание клиента");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"INSERT INTO Clients (FirstName, LastName, Phone, Email) 
                              VALUES (@FirstName, @LastName, @Phone, @Email) RETURNING Id";
                entity = Client.CreateEntity(connection.QueryFirst<int>(query, entity), entity.FirstName, entity.LastName, entity.Phone, entity.Email);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка создания клиента");
                throw;
            }
        }

        public Client? ReadEntity(int id)
        {
            _logger.LogInformation("Чтение клиента по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = "SELECT * FROM Clients WHERE Id = @Id";
                return connection.QueryFirstOrDefault<Client>(query, new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения клиента");
                throw;
            }
        }

        public IEnumerable<Client> ReadEntities()
        {
            _logger.LogInformation("Чтение всех клиентов");

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                return connection.Query<Client>("SELECT * FROM Clients");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения клиентов");
                throw;
            }
        }

        public void UpdateEntity(Client entity)
        {
            _logger.LogInformation("Обновление клиента");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"UPDATE Clients SET FirstName = @FirstName, LastName = @LastName, 
                              Phone = @Phone, Email = @Email WHERE Id = @Id";
                connection.Execute(query, entity);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка обновления клиента");
                throw;
            }
        }

        public void DeleteEntity(int id)
        {
            _logger.LogInformation("Удаление клиента по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Execute("DELETE FROM Clients WHERE Id = @Id", new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка удаления клиента");
                throw;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Dapper;
using Lab4.Entities;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Lab4.Repositories.Implementations
{
    internal class EquipmentRepository : IEquipmentRepository
    {
        private readonly IConnectionString _connectionString;
        private readonly ILogger<EquipmentRepository> _logger;

        public EquipmentRepository(IConnectionString connectionString, ILogger<EquipmentRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public void CreateEntity(Equipment entity)
        {
            _logger.LogInformation("Создание оборудования");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"INSERT INTO Equipment (Name, Model, Price, Quantity, Category) 
                              VALUES (@Name, @Model, @Price, @Quantity, @Category) RETURNING Id";
                // Поскольку Id private, обновляем entity (или возвращаем новый)
                var newId = connection.QueryFirst<int>(query, entity);
                // Если нужно обновить entity.Id - но поскольку private set, используйте в формах новый объект
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка создания оборудования");
                throw;
            }
        }

        public Equipment? ReadEntity(int id)
        {
            _logger.LogInformation("Чтение оборудования по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                return connection.QueryFirstOrDefault<Equipment>("SELECT * FROM Equipment WHERE Id = @Id", new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения оборудования");
                throw;
            }
        }

        public IEnumerable<Equipment> ReadEntities()
        {
            _logger.LogInformation("Чтение всех оборудования");

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                return connection.Query<Equipment>("SELECT * FROM Equipment");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения оборудования");
                throw;
            }
        }

        public void UpdateEntity(Equipment entity)
        {
            _logger.LogInformation("Обновление оборудования");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(entity));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var query = @"UPDATE Equipment SET Name = @Name, Model = @Model, Price = @Price, 
                              Quantity = @Quantity, Category = @Category WHERE Id = @Id";
                connection.Execute(query, entity);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка обновления оборудования");
                throw;
            }
        }

        public void DeleteEntity(int id)
        {
            _logger.LogInformation("Удаление оборудования по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Execute("DELETE FROM Equipment WHERE Id = @Id", new { Id = id });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка удаления оборудования");
                throw;
            }
        }
    }
}
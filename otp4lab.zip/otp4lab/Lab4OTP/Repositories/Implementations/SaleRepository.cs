﻿using System;
using System.Collections.Generic;
using System.Linq;
using Dapper;
using Lab4.Entities;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace Lab4.Repositories.Implementations
{
    internal class SaleRepository : ISaleRepository
    {
        private readonly IConnectionString _connectionString;
        private readonly ILogger<SaleRepository> _logger;

        public SaleRepository(IConnectionString connectionString, ILogger<SaleRepository> logger)
        {
            _connectionString = connectionString;
            _logger = logger;
        }

        public void CreateOperation(Sale sale)
        {
            _logger.LogInformation("Создание операции продажи");
            _logger.LogDebug("Объект: {json}", Newtonsoft.Json.JsonConvert.SerializeObject(sale));

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                connection.Open();
                using var transaction = connection.BeginTransaction();

                var insertSale = @"INSERT INTO Sales (Date, SellerId, ClientId) 
                                   VALUES (@Date, @SellerId, @ClientId) RETURNING Id";
                var saleId = connection.QueryFirst<int>(insertSale, sale, transaction);

                var insertItem = @"INSERT INTO SaleItems (SaleId, EquipmentId, Quantity) 
                                   VALUES (@SaleId, @EquipmentId, @Quantity)";
                foreach (var item in sale.Items)
                {
                    connection.Execute(insertItem, new { SaleId = saleId, item.EquipmentId, item.Quantity }, transaction);
                }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка создания операции продажи");
                throw;
            }
        }

        public IEnumerable<Sale> ReadOperations(DateTime? dateFrom = null, DateTime? dateTo = null, int? sellerId = null, int? clientId = null)
        {
            _logger.LogInformation("Чтение операций продаж");

            var sql = "SELECT * FROM Sales WHERE 1=1";
            var parameters = new DynamicParameters();

            if (dateFrom.HasValue)
            {
                sql += " AND Date >= @DateFrom";
                parameters.Add("DateFrom", dateFrom.Value);
            }
            if (dateTo.HasValue)
            {
                sql += " AND Date <= @DateTo";
                parameters.Add("DateTo", dateTo.Value);
            }
            if (sellerId.HasValue)
            {
                sql += " AND SellerId = @SellerId";
                parameters.Add("SellerId", sellerId.Value);
            }
            if (clientId.HasValue)
            {
                sql += " AND ClientId = @ClientId";
                parameters.Add("ClientId", clientId.Value);
            }

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var sales = connection.Query<Sale>(sql, parameters);
                // Загрузка Items для каждой Sale
                foreach (var s in sales)
                {
                    s.Items = connection.Query<SaleItem>("SELECT EquipmentId, Quantity FROM SaleItems WHERE SaleId = @SaleId", new { SaleId = s.Id }).ToList();
                }
                return sales;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения операций продаж");
                throw;
            }
        }

        public Sale? ReadOperation(int id)
        {
            _logger.LogInformation("Чтение операции продажи по ID {id}", id);

            try
            {
                using var connection = new NpgsqlConnection(_connectionString.Value);
                var sale = connection.QueryFirstOrDefault<Sale>("SELECT * FROM Sales WHERE Id = @Id", new { Id = id });
                if (sale != null)
                {
                    sale.Items = connection.Query<SaleItem>("SELECT EquipmentId, Quantity FROM SaleItems WHERE SaleId = @SaleId", new { SaleId = id }).ToList();
                }
                return sale;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка чтения операции продажи");
                throw;
            }
        }
    }
}
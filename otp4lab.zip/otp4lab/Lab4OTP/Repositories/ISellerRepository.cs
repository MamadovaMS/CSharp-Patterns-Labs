﻿using Lab4.Entities;

namespace Lab4.Repositories
{
    public interface ISellerRepository
    {
        void CreateEntity(Seller seller);
        IEnumerable<Seller> ReadEntities();
        Seller? ReadEntity(int id);
        void UpdateEntity(Seller seller);
        void DeleteEntity(int id);
    }
}
﻿using System;
using System.Collections.Generic;
using Lab4.Entities;

namespace Lab4.Repositories
{
    public interface ISaleRepository
    {
        void CreateOperation(Sale sale);
        IEnumerable<Sale> ReadOperations(DateTime? dateFrom = null, DateTime? dateTo = null, int? sellerId = null, int? clientId = null);
        Sale? ReadOperation(int id);
    }
}
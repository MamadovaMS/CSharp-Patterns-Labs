﻿namespace Lab4.Repositories
{
    internal interface IConnectionString
    {
        string Value { get; }
    }
}
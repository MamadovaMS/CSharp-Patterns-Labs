﻿using Lab4.Entities;

namespace Lab4.Repositories
{
    public interface IClientRepository
    {
        void CreateEntity(Client client);
        IEnumerable<Client> ReadEntities();
        Client? ReadEntity(int id);
        void UpdateEntity(Client client);
        void DeleteEntity(int id);
    }
}
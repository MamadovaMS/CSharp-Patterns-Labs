﻿using Lab4.Entities;

namespace Lab4.Repositories
{
    public interface ISupplyRepository
    {
        void CreateOperation(Supply supply);
        IEnumerable<Supply> ReadOperations(DateTime? dateFrom = null, DateTime? dateTo = null, int? sellerId = null);
        Supply? ReadOperation(int id);
        void DeleteOperation(int id);
    }
}
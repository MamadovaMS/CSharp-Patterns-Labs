﻿using Lab4.Entities;
using System.Collections.Generic;

namespace Lab4.Repositories
{
    public interface IEquipmentRepository
    {
        void CreateEntity(Equipment entity);
        Equipment? ReadEntity(int id);
        IEnumerable<Equipment> ReadEntities();
        void UpdateEntity(Equipment entity);
        void DeleteEntity(int id);
    }
}